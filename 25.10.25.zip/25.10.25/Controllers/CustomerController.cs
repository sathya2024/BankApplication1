﻿using System;
using System.Web.Mvc;
using BankingService.Services;
using Banking;

namespace BankingWeb.Controllers
{
    public class CustomerController : Controller
    {
        private readonly CustomerService _service;

        public CustomerController()
        {
            _service = new CustomerService();
        }

        // Dashboard
        public ActionResult Dashboard()
        {
            string refid = Session["RefID"]?.ToString();
            if (string.IsNullOrEmpty(refid))
                return RedirectToAction("Index", "Login");

            var model = _service.GetDashboard();
            if (model == null)
            {
                ViewBag.ErrorMessage = "Customer not found.";
                return RedirectToAction("Index", "Login");
            }

            return View(model);
        }


        // Account Details
        public ActionResult AccountDetails()
        {
            string customerId = Session["RefID"]?.ToString();
            if (string.IsNullOrEmpty(customerId))
                return RedirectToAction("Index", "Login");

            var model = _service.GetAccountDetails();
            return View(model);
        }

        // Savings Tab
        public ActionResult SavingsView()
        {
            string customerId = Session["RefID"]?.ToString();
            if (string.IsNullOrEmpty(customerId))
                return RedirectToAction("Index", "Login");

            var model = _service.GetSavingsDetails();
            ViewBag.CustomerId = customerId;
            return View(model);
        }

        public PartialViewResult SavingsDetails()
        {
            string customerId = Session["RefID"]?.ToString();
            var model = _service.GetSavingsDetails();
            return PartialView("_SavingsDetails", model);
        }

        public PartialViewResult DepositForm()
        {
            string customerId = Session["RefID"]?.ToString();
            var model = _service.GetSavingsDetails();
            return PartialView("_DepositForm", model);
        }

        //[HttpPost]
        //public ActionResult Deposit(decimal amount)
        //{
        //    string customerId = Session["RefID"]?.ToString();
        //    var accountId = _service.GetSavingsAccountId();
        //    var success = _service.Deposit(amount);
        //    TempData["Message"] = success ? "Deposit successful" : "Deposit failed";
        //    return RedirectToAction("SavingsView");
        //}
        [HttpPost]
        public ActionResult Deposit(decimal amount)
        {
            string customerId = Session["RefID"]?.ToString();
            var accountId = _service.GetSavingsAccountId();

            string message;
            var success = _service.Deposit(amount, out message);

            TempData["Message"] = message;
            TempData["Success"] = success;

            return RedirectToAction("SavingsView");
        }

        public PartialViewResult WithdrawForm()
        {
            string customerId = Session["RefID"]?.ToString();
            var model = _service.GetSavingsDetails();
            return PartialView("_WithdrawForm", model);
        }
        [HttpPost]
        public ActionResult Withdraw(decimal amount)
        {
            string customerId = Session["RefID"]?.ToString();
            var accountId = _service.GetSavingsAccountId();

            string message;
            var success = _service.Withdraw(amount, out message);

            TempData["Message"] = message;
            TempData["Success"] = success;

            return RedirectToAction("SavingsView");
        }


        //[HttpPost]
        //public ActionResult Withdraw(decimal amount)
        //{
        //    string customerId = Session["RefID"]?.ToString();
        //    var accountId = _service.GetSavingsAccountId();
        //    var success = _service.Withdraw(amount);
        //    TempData["Message"] = success ? "Withdrawal successful" : "Withdrawal failed";
        //    return RedirectToAction("SavingsView");
        //}

        public PartialViewResult SavingsTransactions()
        {
            string customerId = Session["RefID"]?.ToString();
            var accountId = _service.GetSavingsAccountId();
            var transactions = _service.GetTopTransactions(3);
            return PartialView("_SavingsTransactions", transactions);
        }

        //public PartialViewResult ViewAllTransactions()
        //{
        //    string customerId = Session["RefID"]?.ToString();
        //    var accountId = _service.GetSavingsAccountId();
        //    var transactions = _service.GetSavingsTransactions();
        //    return PartialView("_SavingsTransactions", transactions);
        //}
        public PartialViewResult ViewAllTransactions(int page = 1, int pageSize = 5)
        {
            var transactions = _service.GetSavingsTransactionsPaged(page, pageSize);
            int totalRecords = _service.GetSavingsTransactionsCount();

            ViewBag.CurrentPage = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalRecords = totalRecords;

            return PartialView("_SavingsTransactionsPaged", transactions);
        }


        // ✅ GET: Transfer Funds Page
        public ActionResult TransferFunds()
        {
            string senderId = Session["RefID"]?.ToString();
            if (string.IsNullOrEmpty(senderId))
                return RedirectToAction("Index", "Login");

            ViewBag.SenderId = senderId;
            return View();
        }

        // ✅ POST: Perform Transfer
        [HttpPost]
        public ActionResult TransferFunds(string receiverId, decimal amount)
        {
            string senderId = Session["RefID"]?.ToString();
            if (string.IsNullOrEmpty(senderId))
                return RedirectToAction("Index", "Login");

            string message;
            var success = _service.TransferFunds(receiverId, amount, out message);

            TempData["Message"] = message;
            TempData["Success"] = success;

            return RedirectToAction("TransferFunds");
        }

        // ✅ For AJAX receiver suggestions
        [HttpGet]
        public JsonResult SearchCustomer(string term)
        {
            var results = _service.SearchCustomerIds(term);
            return Json(results, JsonRequestBehavior.AllowGet);
        }


        // FD Main View
        public ActionResult FDView()
        {
            string customerId = Session["RefID"]?.ToString();
            ViewBag.CustomerId = customerId;
            var model = _service.GetFDDetails();
            return View(model);
        }

        public PartialViewResult FDDetails()
        {
            string customerId = Session["RefID"]?.ToString();
            var model = _service.GetFDDetails();
            return PartialView("_FDDetails", model);
        }

        public PartialViewResult FDTransactions()
        {
            string customerId = Session["RefID"]?.ToString();
            var transactions = _service.GetFDTransactions();
            return PartialView("_FDTransactions", transactions);
        }

        public PartialViewResult FDClosureForm()
        {
            ViewBag.CustomerId = Session["RefID"]?.ToString();
            return PartialView("_FDClosureForm");
        }

        [HttpPost]
        public ActionResult PrematureWithdraw(string fdAccountId)
        {
            string customerId = Session["RefID"]?.ToString();
            var result = _service.PrematureWithdrawFD(fdAccountId);
            TempData["Message"] = result.Message;
            TempData["Success"] = result.Success;
            TempData["Amount"] = result.Amount;
            return RedirectToAction("FDView");
        }

        [HttpPost]
        public ActionResult WithdrawFD(string fdAccountId)
        {
            string customerId = Session["RefID"]?.ToString();
            var result = _service.WithdrawFD(fdAccountId);
            TempData["Message"] = result.Message;
            TempData["Success"] = result.Success;
            TempData["Amount"] = result.Amount;
            return RedirectToAction("FDView");
        }

        // Loan views
        public ActionResult LoanView()
        {
            string customerId = Session["RefID"]?.ToString();
            var loans = _service.GetAllLoans();
            ViewBag.CustomerId = customerId;
            return View(loans);
        }

        public PartialViewResult LoanDetails(string loanId)
        {
            var loan = _service.GetLoanById(loanId);
            return PartialView("_LoanDetails", loan);
        }

        public PartialViewResult EMI(string loanId)
        {
            var loan = _service.GetLoanById(loanId);
            ViewBag.LoanId = loanId;
            ViewBag.CustomerId = loan?.CustomerId;
            return PartialView("_EMI");
        }

        public ActionResult AutoPayEMI(string loanId)
        {
            var loan = _service.GetLoanById(loanId);
            if (loan == null || !loan.Emi.HasValue || !loan.DueAmount.HasValue)
            {
                TempData["Message"] = "Loan not found or EMI not available.";
                return RedirectToAction("LoanView");
            }

            var emiAmount = Math.Ceiling(loan.Emi.Value);
            var success = _service.PayEMI(loanId, emiAmount);
            TempData["Message"] = success ? $"EMI of ₹{emiAmount:N0} paid successfully." : "EMI payment failed.";
            return RedirectToAction("LoanView");
        }

        public PartialViewResult PartPay(string loanId)
        {
            var loan = _service.GetLoanById(loanId);
            ViewBag.LoanId = loanId;
            ViewBag.CustomerId = loan?.CustomerId;
            return PartialView("_PartPay");
        }

        [HttpPost]
        public ActionResult PartPay(decimal amount, string loanId)
        {
            string customerId = Session["RefID"]?.ToString();
            var success = _service.PartPay(loanId, amount);
            TempData["Message"] = success ? "Part payment successful." : "Payment failed.";
            return RedirectToAction("LoanView");
        }

        public ActionResult Foreclose(string loanId)
        {
            var loan = _service.GetLoanById(loanId);
            if (loan == null)
            {
                TempData["Message"] = "Loan not found.";
                return RedirectToAction("LoanView");
            }
            return View("_Foreclose", loan);
        }

        [HttpPost]
        public ActionResult ForecloseLoan(string loanId)
        {
            string customerId = Session["RefID"]?.ToString();
            var success = _service.ForecloseLoan(loanId);
            TempData["Message"] = success ? "Loan foreclosed successfully." : "Foreclosure failed.";
            return RedirectToAction("LoanView");
        }

        public PartialViewResult LoanTransactions(string loanId)
        {
            var txns = _service.GetLoanTransactionsByLoanId(loanId);
            return PartialView("_LoanTransactions", txns);
        }
    }
}
