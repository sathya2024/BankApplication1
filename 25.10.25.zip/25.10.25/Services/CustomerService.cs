﻿using Banking;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;

namespace BankingService.Services
{
    public class CustomerService
    {
        private readonly BankDBEntities _context;

        public CustomerService()
        {
            _context = new BankDBEntities();
        }

        // Helper to get current logged-in customer ID from session
        private string CurrentCustomerId => HttpContext.Current?.Session["RefID"]?.ToString();

        // Dashboard Summary
        public CustomerDashboardViewModel GetDashboard()
        {
            var customerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(customerId)) return null;

            var customer = _context.Customers.FirstOrDefault(c => c.CustomerId == customerId);
            if (customer == null) return null;

            return new CustomerDashboardViewModel
            {
                CustomerId = customer.CustomerId,
                Name = customer.CustomerName,
                Email = customer.CustomerEmail,
                HasSavings = _context.SavingsAccounts.Any(sa => sa.CustomerId == customerId),
                HasFD = _context.FixedDeposits.Any(fd => fd.CustomerId == customerId),
                HasLoan = _context.LoanAccounts.Any(ln => ln.CustomerId == customerId)
            };
        }

        // Account Details
        public List<Account> GetAccountDetails()
        {
            var customerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(customerId)) return new List<Account>();
            return _context.Accounts.Where(a => a.CustomerId == customerId).ToList();
        }

        // Savings
        public SavingsAccount GetSavingsDetails()
        {
            var customerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(customerId)) return null;
            return _context.SavingsAccounts.FirstOrDefault(sa => sa.CustomerId == customerId);
        }

        public string GetSavingsAccountId()
        {
            var customerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(customerId)) return null;
            return _context.SavingsAccounts
                .Where(sa => sa.CustomerId == customerId)
                .Select(sa => sa.SBAccountId)
                .FirstOrDefault();
        }

        //public bool Deposit(decimal amount)
        //{
        //    var accountId = GetSavingsAccountId();
        //    if (string.IsNullOrEmpty(accountId) || amount < 100) return false;

        //    var account = _context.SavingsAccounts.FirstOrDefault(sa => sa.SBAccountId == accountId);
        //    if (account == null) return false;

        //    account.Balance += amount;
        //    _context.SavingsTransactions.Add(new SavingsTransaction
        //    {
        //        SBAccountId = accountId,
        //        Amount = amount,
        //        TransactionType = "D",
        //        TransactionDate = DateTime.Now
        //    });
        //    _context.SaveChanges();
        //    return true;
        //}

        //public bool Withdraw(decimal amount)
        //{
        //    var accountId = GetSavingsAccountId();
        //    var account = _context.SavingsAccounts.FirstOrDefault(sa => sa.SBAccountId == accountId);
        //    if (account == null || amount < 100 || account.Balance - amount < 1000) return false;

        //    account.Balance -= amount;
        //    _context.SavingsTransactions.Add(new SavingsTransaction
        //    {
        //        SBAccountId = accountId,
        //        Amount = amount,
        //        TransactionType = "W",
        //        TransactionDate = DateTime.Now
        //    });
        //    _context.SaveChanges();
        //    return true;
        //}
        // In your BankingService class
        public bool Deposit(decimal amount, out string message)
        {
            var accountId = GetSavingsAccountId();
            if (string.IsNullOrEmpty(accountId))
            {
                message = "No savings account found.";
                return false;
            }

            if (amount < 100)
            {
                message = "Deposit amount must be at least ₹100.";
                return false;
            }

            var account = _context.SavingsAccounts.FirstOrDefault(sa => sa.SBAccountId == accountId);
            if (account == null)
            {
                message = "Savings account not found.";
                return false;
            }

            account.Balance += amount;

            _context.SavingsTransactions.Add(new SavingsTransaction
            {
                SBAccountId = accountId,
                Amount = amount,
                TransactionType = "D",
                TransactionDate = DateTime.Now
            });

            _context.SaveChanges();
            message = $"Deposit of ₹{amount:N2} successful. New balance: ₹{account.Balance:N2}.";
            return true;
        }

        public bool Withdraw(decimal amount, out string message)
        {
            var accountId = GetSavingsAccountId();
            if (string.IsNullOrEmpty(accountId))
            {
                message = "No savings account found.";
                return false;
            }

            var account = _context.SavingsAccounts.FirstOrDefault(sa => sa.SBAccountId == accountId);
            if (account == null)
            {
                message = "Savings account not found.";
                return false;
            }

            if (amount < 100)
            {
                message = "Withdrawal amount must be at least ₹100.";
                return false;
            }

            if (account.Balance - amount < 1000)
            {
                message = "Insufficient balance. A minimum of ₹1000 must remain after withdrawal.";
                return false;
            }

            account.Balance -= amount;

            _context.SavingsTransactions.Add(new SavingsTransaction
            {
                SBAccountId = accountId,
                Amount = amount,
                TransactionType = "W",
                TransactionDate = DateTime.Now
            });

            _context.SaveChanges();
            message = $"Withdrawal of ₹{amount:N2} successful. Remaining balance: ₹{account.Balance:N2}.";
            return true;
        }

        public List<SavingsTransaction> GetTopTransactions(int count = 3)
        {
            var accountId = GetSavingsAccountId();
            if (string.IsNullOrEmpty(accountId)) return new List<SavingsTransaction>();

            return _context.SavingsTransactions
                .Where(t => t.SBAccountId == accountId)
                .OrderByDescending(t => t.TransactionDate)
                .Take(count)
                .ToList();
        }

        //public List<SavingsTransaction> GetSavingsTransactions()
        //{
        //    var accountId = GetSavingsAccountId();
        //    if (string.IsNullOrEmpty(accountId)) return new List<SavingsTransaction>();

        //    return _context.SavingsTransactions
        //        .Where(t => t.SBAccountId == accountId)
        //        .OrderByDescending(t => t.TransactionDate)
        //        .ToList();
        //}
        public List<SavingsTransaction> GetSavingsTransactionsPaged(int page, int pageSize)
        {
            var accountId = GetSavingsAccountId();
            if (string.IsNullOrEmpty(accountId)) return new List<SavingsTransaction>();

            return _context.SavingsTransactions
                .Where(t => t.SBAccountId == accountId)
                .OrderByDescending(t => t.TransactionDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }
        public int GetSavingsTransactionsCount()
        {
            var accountId = GetSavingsAccountId();
            if (string.IsNullOrEmpty(accountId)) return 0;

            return _context.SavingsTransactions
                .Count(t => t.SBAccountId == accountId);
        }

        public bool TransferFunds(string receiverCustomerId, decimal amount, out string message)
        {
            message = string.Empty;
            var senderCustomerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(senderCustomerId))
            {
                message = "Session expired. Please log in again.";
                return false;
            }

            if (string.IsNullOrEmpty(receiverCustomerId))
            {
                message = "Receiver Customer ID is required.";
                return false;
            }

            if (receiverCustomerId == senderCustomerId)
            {
                message = "You cannot transfer funds to your own account.";
                return false;
            }

            if (amount < 100)
            {
                message = "Minimum transfer amount is ₹100.";
                return false;
            }

            var senderAccount = _context.SavingsAccounts.FirstOrDefault(sa => sa.CustomerId == senderCustomerId);
            var receiverAccount = _context.SavingsAccounts.FirstOrDefault(sa => sa.CustomerId == receiverCustomerId);

            if (senderAccount == null)
            {
                message = "Sender account not found.";
                return false;
            }

            if (receiverAccount == null)
            {
                message = "Receiver account not found.";
                return false;
            }

            if (senderAccount.Balance - amount < 1000)
            {
                message = "Insufficient balance. Minimum balance of ₹1000 must be maintained.";
                return false;
            }

            // Perform transfer
            senderAccount.Balance -= amount;
            receiverAccount.Balance += amount;

            // Add sender transaction (Withdrawal)
            _context.SavingsTransactions.Add(new SavingsTransaction
            {
                SBAccountId = senderAccount.SBAccountId,
                Amount = amount,
                TransactionType = "W",
                TransactionDate = DateTime.Now,
               // Remarks = $"Transfer to {receiverCustomerId}"
            });

            // Add receiver transaction (Deposit)
            _context.SavingsTransactions.Add(new SavingsTransaction
            {
                SBAccountId = receiverAccount.SBAccountId,
                Amount = amount,
                TransactionType = "D",
                TransactionDate = DateTime.Now,
               // Remarks = $"Transfer from {senderCustomerId}"
            });

            _context.SaveChanges();
            message = $"Successfully transferred ₹{amount} to Customer ID {receiverCustomerId}.";
            return true;
        }
        public List<string> SearchCustomerIds(string term)
        {
            return _context.Customers
                .Where(c => c.CustomerId.StartsWith(term))
                .OrderBy(c => c.CustomerId)
                .Take(5)
                .Select(c => c.CustomerId)
                .ToList();
        }


        // FD
        public List<FixedDeposit> GetFDDetails()
        {
            var customerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(customerId)) return new List<FixedDeposit>();

            return _context.FixedDeposits
     .Where(fd => fd.CustomerId == customerId && fd.Status == "ACTIVE")
     .OrderByDescending(fd => fd.OpenDate)
     .ToList();

        }

        public List<FDTransaction> GetFDTransactions()
        {
            var customerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(customerId)) return new List<FDTransaction>();

            var fdIds = _context.FixedDeposits
                .Where(fd => fd.CustomerId == customerId)
                .Select(fd => fd.FDAccountId)
                .ToList();

            return _context.FDTransactions
                .Where(t => fdIds.Contains(t.FDAccountId))
                .OrderByDescending(t => t.TransactionDate)
                .ToList();
        }

        public string GetCustomerIdByFD(string fdAccountId)
        {
            var fdRecord = _context.FixedDeposits.FirstOrDefault(fd => fd.FDAccountId == fdAccountId);
            return fdRecord?.CustomerId;
        }

        public TransactionResult PrematureWithdrawFD(string fdAccountId)
        {
            var fdRecord = _context.FixedDeposits.FirstOrDefault(fd => fd.FDAccountId == fdAccountId);
            if (fdRecord == null)
                return new TransactionResult { Success = false, Message = "FD not found." };

            fdRecord.Status = "Closed";
            fdRecord.CloseDate = DateTime.Now;
            _context.Entry(fdRecord).State = EntityState.Modified;


            var accountRecord = _context.Accounts.FirstOrDefault(a => a.AccountId == fdAccountId);
            if (accountRecord != null)
            {
                accountRecord.AccountStatus = "Closed";
                accountRecord.CloseDate = DateTime.Now;
                _context.Entry(accountRecord).State = EntityState.Modified;
            }


            var transaction = new FDTransaction
            {
                FDAccountId = fdRecord.FDAccountId,
                TransactionDate = DateTime.Now,
                TransactionType = "Premature Closure",
                Amount = fdRecord.Amount,
                Remark = "FD closed before maturity"
            };

            _context.FDTransactions.Add(transaction);

            try
            {
                _context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var error in validationErrors.ValidationErrors)
                    {
                        Console.WriteLine($"Property: {error.PropertyName} Error: {error.ErrorMessage}");
                    }
                }
                throw;
            }

            return new TransactionResult
            {
                Success = true,
                Message = "FD closed prematurely.",
                Amount = (decimal)transaction.Amount,
                TransactionId = transaction.TransactionId
            };
        }

        public TransactionResult WithdrawFD(string fdAccountId)
        {
            var fdRecord = _context.FixedDeposits.FirstOrDefault(fd => fd.FDAccountId == fdAccountId);
            if (fdRecord == null)
                return new TransactionResult { Success = false, Message = "FD not found." };

            if (DateTime.Today != fdRecord.MaturityDate?.Date)
                return new TransactionResult { Success = false, Message = "FD not yet matured." };

            fdRecord.Status = "Closed";
            fdRecord.CloseDate = DateTime.Now;
            _context.Entry(fdRecord).State = EntityState.Modified;

            var accountRecord = _context.Accounts.FirstOrDefault(a => a.AccountId == fdAccountId);
            if (accountRecord != null)
            {
                accountRecord.AccountStatus = "Closed";
                accountRecord.CloseDate = DateTime.Now;
                _context.Entry(accountRecord).State = EntityState.Modified;
            }


            var transaction = new FDTransaction
            {
                FDAccountId = fdRecord.FDAccountId,
                TransactionDate = DateTime.Now,
                TransactionType = "Maturity Withdrawal",
                Amount = fdRecord.Amount,
                Remark = "FD withdrawn on maturity"
            };

            _context.FDTransactions.Add(transaction);

            try
            {
                _context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var error in validationErrors.ValidationErrors)
                    {
                        Console.WriteLine($"Property: {error.PropertyName} Error: {error.ErrorMessage}");
                    }
                }
                throw;
            }

            return new TransactionResult
            {
                Success = true,
                Message = "FD withdrawn on maturity.",
                Amount = (decimal)transaction.Amount,
                TransactionId = transaction.TransactionId
            };
        }

        // Loans
        public List<LoanAccount> GetAllLoans()
        {
            var customerId = CurrentCustomerId;
            if (string.IsNullOrEmpty(customerId)) return new List<LoanAccount>();

            return _context.LoanAccounts
                .Where(ln => ln.CustomerId == customerId)
                .OrderByDescending(ln => ln.StartDate)
                .ToList();
        }

        public LoanAccount GetLoanById(string loanId)
        {
            return _context.LoanAccounts.FirstOrDefault(ln => ln.LNAccountId == loanId);
        }

        public List<LoanTransaction> GetLoanTransactionsByLoanId(string loanId)
        {
            return _context.LoanTransactions
                .Where(txn => txn.LNAccountId == loanId)
                .OrderByDescending(txn => txn.TransactionDate)
                .ToList();
        }

        public bool PayEMI(string loanId, decimal amount)
        {
            var customerId = CurrentCustomerId;
            var loan = GetLoanById(loanId);
            if (loan == null || loan.CustomerId != customerId || !loan.LoanAmount.HasValue || !loan.TimePeriod.HasValue)
                return false;

            loan.DueAmount = Math.Max(loan.DueAmount.Value - amount, 0);
            _context.LoanTransactions.Add(new LoanTransaction
            {
                LNAccountId = loan.LNAccountId,
                Amount = amount,
                TransactionType = "EMI",
                TransactionDate = DateTime.Now,
                Penalty = 0
            });
            _context.SaveChanges();
            return true;
        }

        public bool PartPay(string loanId, decimal amount)
        {
            var customerId = CurrentCustomerId;
            var loan = GetLoanById(loanId);
            if (loan == null || loan.CustomerId != customerId || amount <= 0) return false;

            loan.DueAmount = Math.Max(loan.DueAmount.Value - amount, 0);
            _context.LoanTransactions.Add(new LoanTransaction
            {
                LNAccountId = loan.LNAccountId,
                Amount = amount,
                TransactionType = "PartPay",
                TransactionDate = DateTime.Now,
                Penalty = 0
            });
            _context.SaveChanges();
            return true;
        }

        public bool ForecloseLoan(string loanId)
        {
            var customerId = CurrentCustomerId;
            var loan = GetLoanById(loanId);
            if (loan == null || loan.CustomerId != customerId) return false;

            _context.LoanTransactions.Add(new LoanTransaction
            {
                LNAccountId = loan.LNAccountId,
                Amount = loan.DueAmount ?? 0m,
                TransactionType = "Foreclose",
                TransactionDate = DateTime.Now,
                Penalty = 0
            });

            loan.LoanStatus = "Foreclosed";
            loan.DueAmount = 0m;

            try
            {
                _context.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine($"Property: {ve.PropertyName}, Error: {ve.ErrorMessage}");
                    }
                }
                return false;
            }
        }
    }



    // ViewModel for Dashboard
    public class CustomerDashboardViewModel
    {
        public string CustomerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public bool HasSavings { get; set; }
        public bool HasFD { get; set; }
        public bool HasLoan { get; set; }
    }
    public class TransactionResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public decimal Amount { get; set; }
        public long TransactionId { get; set; }
        public decimal NewBalance { get; set; }
    }

}


