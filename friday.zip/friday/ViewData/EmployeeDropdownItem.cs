﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.ViewData
{
    public class EmployeeDropdownItem
    {
        public string EmployeeId { get; set; }
        public string DisplayName { get; set; }
    }
}
