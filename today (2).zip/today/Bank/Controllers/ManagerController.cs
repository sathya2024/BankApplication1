﻿using Banking.ViewData;
using Banking;
using BankingService.Services;
using iTextSharp.text;
using iTextSharp.text.pdf;
using OfficeOpenXml;
using OfficeOpenXml.FormulaParsing.Excel.Functions.DateTime;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;

using System.Web;
using System.Web.Mvc;
using System.Web.Services.Description;
namespace Bank.Controllers
{
    public class ManagerController : Controller
    {
        private readonly BankDBEntities _context = new BankDBEntities();
        private readonly ManagerService _managerService;
        public ManagerController()
        {
            _managerService = new ManagerService();
        }



        //-----------------------------------------------------------------------------------------------------------
        //Approve user
        //-------------------------------------------------------------------------------------------------------------
        // GET: Manager
        //public ActionResult Index()
        //{
        //    return View();
        //}
        // GET: Manager/Approve
        public ActionResult Approve()
        {
            var pendingList = _managerService.GetPendingApprovals();
            return View(pendingList);
        }


        [HttpPost]
        public ActionResult ApproveUser(string pan)
        {
            var customer = _context.Customers.FirstOrDefault(c => c.PAN == pan);
            if (customer != null)
            {
                customer.Approval = "Approved";
                _context.Entry(customer).State = System.Data.Entity.EntityState.Modified;
                _context.SaveChanges();
                TempData["Message"] = $"Customer {customer.CustomerName} approved successfully.";
                return RedirectToAction("Approve");
            }

            var employee = _context.Employees.FirstOrDefault(e => e.PAN == pan);
            if (employee != null)
            {
                employee.Approval = "Approved";
                _context.Entry(employee).State = System.Data.Entity.EntityState.Modified;
                _context.SaveChanges();
                TempData["Message"] = $"Employee {employee.EmployeeName} approved successfully.";
                return RedirectToAction("Approve");
            }

            TempData["Message"] = "User not found.";
            return RedirectToAction("Approve");
        }

        //-------------------------------------------------------------------------------------------------------------------------------------
        //Delete Employee 
        //--------------------------------------------------------------------------------------------------------------------------------------
        // GET: Manager/DeleteEmployee
        [HttpGet]
        public ActionResult DeleteEmployee()
        {
            var employees = _context.Employees
                .Where(e => e.Approval == "Approved")
                .ToList();

            return View(employees); // This loads DeleteEmployee.cshtml
        }

        // POST: Manager/DeleteEmployeeConfirmed
        [HttpPost]
        public ActionResult DeleteEmployeeConfirmed(string employeeId)
        {
            try
            {
                var employee = _context.Employees.FirstOrDefault(e => e.EmployeeId == employeeId);
                if (employee != null)
                {
                    var login = _context.LoginDatas.FirstOrDefault(l => l.RefID == employeeId && l.UserRole == "Employee");
                    if (login != null)
                    {
                        _context.LoginDatas.Remove(login);
                    }

                    _context.Employees.Remove(employee);
                    _context.SaveChanges();
                    TempData["Message"] = "Employee deleted successfully.";
                }
                else
                {
                    TempData["Message"] = "Employee not found.";
                }
            }
            catch (Exception ex)
            {
                TempData["Message"] = "Error deleting employee: " + ex.Message;
            }

            return RedirectToAction("DeleteEmployee");
        }


        //-----------------------------------------------------------------------------------------------------------
        //Add Employee
        //-------------------------------------------------------------------------------------------------------------

        // GET: Manager/Employees
        public ActionResult Employees()
        {
            return View();
        }
        // POST: Manager/Employees
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Employees(Employee model, string password)
        {
            if (ModelState.IsValid)
            {
                bool success = _managerService.AddEmployeeWithLogin(model, password);
                if (success)
                {
                    TempData["Message"] = "Employee added successfully!";
                    return RedirectToAction("Employees");
                }
                TempData["Message"] = "Failed to add employee.";
            }
            return View(model);
        }

        //-------------------------------------------------------------------------------------------------------------------------------------
        //Add and delete Customer 
        //--------------------------------------------------------------------------------------------------------------------------------------
        [HttpGet]
        public ActionResult AddCustomer()
        {
            return View("AddCustomer", new Customer());
        }


        [HttpPost]
        public ActionResult AddCustomer(Customer model, string password)
        {
            if (!ModelState.IsValid)
            {
                return View("AddCustomer", model);
            }

            try
            {
                bool success = _managerService.AddCustomerWithLogin(model, password);

                if (success)
                {
                    ViewBag.Message = $"Customer '{model.CustomerName}' added successfully with the customerid {model.CustomerId}!";
                    return View("AddCustomer", new Customer()); // Reset form
                }
                else
                {
                    ModelState.AddModelError("", "Failed to add customer. Please try again.");
                    return View("AddCustomer", model);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error: " + ex.Message);
                return View("AddCustomer", model);
            }
        }


        // GET: /Customer/DeleteCustomer
        [HttpGet]
        public ActionResult DeleteCustomer()
        {
            var customers = _managerService.GetAllCustomers(); // You need to fetch the list
            return View("DeleteCustomer", customers);
        }

        // POST: /Customer/DeleteCustomer
        [HttpPost]
        public ActionResult DeleteCustomer(string customerId)
        {
            bool success = _managerService.DeleteCustomer(customerId);

            if (success)
            {
                TempData["Message"] = $"Customer {customerId} deleted successfully.";
            }
            else
            {
                TempData["Message"] = $"Cannot delete customer {customerId}. Active account(s) exist.";
            }

            return RedirectToAction("DeleteCustomer"); // Redirect back to the list
        }

        //-------------------------------------------------------------------------------------------------------------------------------------
        //Add and delete Savings Account
        //--------------------------------------------------------------------------------------------------------------------------------------
        [HttpGet]
        public ActionResult SavingsAccount()
        {
            return View("SavingsAccount");
        }

        [HttpGet]
        public ActionResult LoadPartial(string name)
        {
            switch (name)
            {
                case "_CreateSBAccount":
                    return PartialView("_CreateSBAccount");
                case "_CloseSBAccount":
                    return PartialView("_CloseSBAccount");
                case "_ViewSBTransactions":
                    var transactions = _managerService.GetAllSBTransactions();
                    return PartialView("_ViewSBTransactions", transactions);
                default:
                    return Content("Invalid request");
            }
        }

        // GET: Manager/_CreateSBAccount



        [HttpGet]
        public PartialViewResult CreateSBAccount()
        {
            return PartialView("_CreateSBAccount", new Customer());
        }

        [HttpPost]
        public PartialViewResult CreateSBAccount(Customer customer, decimal initialDeposit, int createdBy)
        {
            try
            {
                if (customer == null || string.IsNullOrEmpty(customer.CustomerId))
                {
                    ViewBag.Message = "Please provide valid customer details.";
                    return PartialView("_CreateSBAccount", customer);
                }

                string generatedAccountId;
                var service = new ManagerService();
                bool success = service.CreateSBAccountWithDetails(customer, initialDeposit, createdBy, out generatedAccountId);

                if (success)
                {
                    ViewBag.Message = $"Savings Account created successfully! Account ID: {generatedAccountId}";
                    return PartialView("_CreateSBAccount", new Customer());
                }
                else
                {
                    ViewBag.Message = "Error creating account. Please check the details and try again.";
                    return PartialView("_CreateSBAccount", customer);
                }
            }
            catch (Exception ex)
            {

                ViewBag.Message = "Error creating account: " + ex.Message;
                return PartialView("_CreateSBAccount", customer);
            }
        }

        [HttpGet]
        public JsonResult GetCustomerDetails(string customerId)
        {
            var customer = _context.Customers.SingleOrDefault(c => c.CustomerId == customerId);
            if (customer == null)
                return Json(new { success = false, message = "Customer not found." }, JsonRequestBehavior.AllowGet);

            return Json(new
            {
                success = true,
                data = new
                {
                    customer.CustomerName,
                    customer.PhoneNumber,
                    customer.CustomerDOB,
                    customer.CustomerAddress,
                    customer.CustomerEmail,
                    customer.PAN
                }
            }, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public PartialViewResult CloseSBAccount()
        {
            return PartialView("_CloseSBAccount");
        }

        [HttpPost]
        public PartialViewResult _CloseSBAccount(string accountId, int closedBy)
        {
            var accountDetails = _managerService.GetSBAccountDetails(accountId);

            if (accountDetails == null)
            {
                ViewBag.Message = "Account not found.";
                return PartialView("_CloseSBAccount");
            }

            bool result = _managerService.CloseSBAccount(accountId);

            ViewBag.Message = result
                ? $"Account {accountId} closed successfully by Employee ID {closedBy}."
                : "Error closing account.";

            return PartialView("_CloseSBAccount", accountDetails);
        }

        //-----------------------------------------------------------------------------------------------------------
        //Main Transactions Tab — shows all transactions initially
        //-------------------------------------------------------------------------------------------------------------


        [HttpGet]
        public PartialViewResult ViewSBTransactions()
        {
            var transactions = _managerService.GetAllSBTransactions();
            return PartialView("_ViewSBTransactions", transactions);
        }

        // GET: Deposit Partial
        [HttpGet]
        public PartialViewResult Deposit()
        {
            return PartialView("_DepositTransaction");
        }

        // POST: Deposit
        [HttpPost]
        public PartialViewResult Deposit(string sbAccountId, decimal amount)
        {
            // Call service
            string message = _managerService.Deposit(sbAccountId, amount);
            ViewBag.Message = message;

            // Load recent transactions for this account
            ViewBag.Transactions = _managerService.GetTransactionsByAccount(sbAccountId);

            return PartialView("_DepositTransaction");
        }

        // GET: Withdraw Partial
        [HttpGet]
        public PartialViewResult Withdraw()
        {
            return PartialView("_WithdrawTransaction");
        }

        // POST: Withdraw
        [HttpPost]
        public PartialViewResult Withdraw(string sbAccountId, decimal amount)
        {
            // Call service
            string message = _managerService.Withdraw(sbAccountId, amount);
            ViewBag.Message = message;

            // Load recent transactions for this account
            ViewBag.Transactions = _managerService.GetTransactionsByAccount(sbAccountId);

            return PartialView("_WithdrawTransaction");
        }


        //// GET: Transaction History Partial
        [HttpGet]
        public PartialViewResult TransactionHistory()
        {
            // Initially, show all transactions (or empty if you want user to input account)
            var transactions = _managerService.GetAllSBTransactions();
            return PartialView("_TransactionHistory", transactions);
        }

        // Optional: POST to filter by account
        [HttpPost]
        public PartialViewResult TransactionHistory(string sbAccountId)
        {
            List<SavingsTransaction> transactions;
            if (!string.IsNullOrEmpty(sbAccountId))
            {
                transactions = _managerService.GetTransactionsByAccount(sbAccountId);
            }
            else
            {
                transactions = _managerService.GetAllSBTransactions();
            }

            ViewBag.AccountId = sbAccountId;
            return PartialView("_TransactionHistory", transactions);
        }
        // GET: Load Export Partial
        [HttpGet]
        public PartialViewResult ExportTransactions()
        {
            return PartialView("_ExportTransactions", new List<SavingsTransaction>());
        }

        // POST: Filter transactions by account
        [HttpPost]
        public PartialViewResult ExportTransactions(string sbAccountId)
        {
            List<SavingsTransaction> transactions = new List<SavingsTransaction>();
            if (!string.IsNullOrEmpty(sbAccountId))
            {
                transactions = _managerService.GetTransactionsByAccount(sbAccountId);
            }

            ViewBag.AccountId = sbAccountId;
            return PartialView("_ExportTransactions", transactions);
        }

        // POST: Export filtered transactions to Excel
        [HttpPost]
        public ActionResult ExportToExcel(string sbAccountId)
        {
            var transactions = _managerService.GetTransactionsByAccount(sbAccountId);

            using (var package = new ExcelPackage())
            {
                var ws = package.Workbook.Worksheets.Add("Transactions");
                ws.Cells[1, 1].Value = "Transaction ID";
                ws.Cells[1, 2].Value = "Account ID";
                ws.Cells[1, 3].Value = "Amount";
                ws.Cells[1, 4].Value = "Type";
                ws.Cells[1, 5].Value = "Date & Time";
                ws.Cells[1, 6].Value = "Balance";

                int row = 2;
                foreach (var t in transactions)
                {
                    ws.Cells[row, 1].Value = t.TransactionId;
                    ws.Cells[row, 2].Value = t.SBAccountId;
                    ws.Cells[row, 3].Value = t.Amount;
                    ws.Cells[row, 4].Value = t.TransactionType;
                    ws.Cells[row, 5].Value = t.TransactionDate?.ToString("dd-MM-yyyy HH:mm:ss");
                    ws.Cells[row, 6].Value = t.Balance;
                    row++;
                }

                var stream = new MemoryStream();
                package.SaveAs(stream);
                stream.Position = 0;
                string fileName = $"Transactions_{sbAccountId}_{DateTime.Now:yyyyMMddHHmmss}.xlsx";
                return File(stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
        }

        // POST: Export filtered transactions to PDF
        [HttpPost]
        public ActionResult ExportToPDF(string sbAccountId)
        {
            var transactions = _managerService.GetTransactionsByAccount(sbAccountId);

            using (MemoryStream ms = new MemoryStream())
            {
                Document doc = new Document(PageSize.A4, 10, 10, 10, 10);
                PdfWriter.GetInstance(doc, ms);
                doc.Open();

                Paragraph title = new Paragraph($"Transaction History for Account {sbAccountId}")
                {
                    Alignment = Element.ALIGN_CENTER,
                    SpacingAfter = 20f
                };
                doc.Add(title);

                PdfPTable table = new PdfPTable(6) { WidthPercentage = 100 };
                table.AddCell("Transaction ID");
                table.AddCell("Account ID");
                table.AddCell("Amount");
                table.AddCell("Type");
                table.AddCell("Date & Time");
                table.AddCell("Balance");

                foreach (var t in transactions)
                {
                    table.AddCell(t.TransactionId.ToString());
                    table.AddCell(t.SBAccountId);
                    table.AddCell(t.Amount.ToString());
                    table.AddCell(t.TransactionType);
                    table.AddCell(t.TransactionDate?.ToString("dd-MM-yyyy HH:mm:ss") ?? "-");
                    table.AddCell(t.Balance.ToString());
                }

                doc.Add(table);
                doc.Close();

                byte[] bytes = ms.ToArray();
                string fileName = $"Transactions_{sbAccountId}_{DateTime.Now:yyyyMMddHHmmss}.pdf";
                return File(bytes, "application/pdf", fileName);
            }
        }

        //-------------------------------------------------------------------------------------------------------------------------------------
        //close Loan Account
        //--------------------------------------------------------------------------------------------------------------------------------------
        [HttpGet]
        public PartialViewResult _CloseLoanAccount()
        {
            return PartialView("_CloseLoanAccount", new LoanAccount());
        }

        [HttpPost]
        public PartialViewResult _CloseLoanAccount(string LNAccountId)
        {
            var loan = _managerService.GetLoanById(LNAccountId);
            if (loan == null)
            {
                ViewBag.Message = "Loan account not found.";
                return PartialView("_CloseLoanAccount");
            }

            if (loan.DueAmount > 0)
            {
                ViewBag.Message = $"Loan cannot be closed. Outstanding due: ₹{loan.DueAmount:F2}";
                return PartialView("_CloseLoanAccount");
            }

            try
            {
                _managerService.CloseLoanAccount(loan);
                ViewBag.Message = "Loan account closed successfully.";
            }
            catch (Exception ex)
            {
                ViewBag.Message = "Error closing loan account: " + ex.Message;
            }

            return PartialView("_CloseLoanAccount");
        }

        //-------------------------------------------------------------------------------------------------------------------------------------
        //Create Loan Account
        //--------------------------------------------------------------------------------------------------------------------------------------

        [HttpGet]
        public ActionResult LoanAccount()
        {
            var loan = new LoanAccount
            {
                LNAccountId = _managerService.GenerateLoanAccountId()
            };
            return View("_LoanAccountMain", loan);
        }

        [HttpGet]
        public PartialViewResult _CreateLoanAccount()
        {
            return PartialView("_CreateLoanAccount", new LoanAccount
            {
                LNAccountId = _managerService.GenerateLoanAccountId()
            });
        }

        [HttpPost]
        public PartialViewResult _CreateLoanAccount(string customerId, decimal loanAmount, decimal monthlyIncome, decimal timePeriod)
        {
            try
            {
                var customer = _managerService.GetCustomerById(customerId);
                if (customer == null)
                {
                    ViewBag.Message = "❌ Customer not found.";
                    return PartialView("_CreateLoanAccount");
                }

                string loanAccountId = _managerService.GenerateLoanAccountId();

                var loan = new LoanAccount
                {
                    LNAccountId = loanAccountId,
                    CustomerId = customerId,
                    LoanAmount = loanAmount,
                    TimePeriod = timePeriod,
                    MonthDueDate = DateTime.Now.Day
                };

                string errorMessage;
                decimal emi;

                var processedLoan = _managerService.ProcessLoan(loan, customer, monthlyIncome, out errorMessage, out emi);

                if (processedLoan == null)
                {
                    ViewBag.Message = $" {errorMessage}";
                    return PartialView("_CreateLoanAccount", loan);
                }

                processedLoan.LoanStatus = "Active";

                var account = new Account
                {
                    AccountId = loanAccountId,
                    CustomerId = customerId,
                    CreatedBy = 12345,
                    OpenDate = DateTime.Now,
                    AccountStatus = "Active"
                };

                _context.Accounts.Add(account);
                _context.LoanAccounts.Add(processedLoan);
                _context.SaveChanges();

                ViewBag.Message = $" Loan sanctioned successfully.<br/>" +
                                  $"Account ID: <strong>{loanAccountId}</strong><br/>" +
                                  $"EMI: ₹<strong>{Math.Round(emi, 2)}</strong><br/>" +
                                  $"Interest Rate: <strong>{processedLoan.Interest}%</strong>";

                return PartialView("_CreateLoanAccount", new LoanAccount());
            }
            catch (DbUpdateException dbEx)
            {
                string innerMessage = dbEx.InnerException?.InnerException?.Message
                                      ?? dbEx.InnerException?.Message
                                      ?? dbEx.Message;

                ViewBag.Message = " Database error: " + innerMessage;
                System.Diagnostics.Debug.WriteLine("DB Error: " + dbEx.ToString());
                return PartialView("_CreateLoanAccount");
            }
            catch (Exception ex)
            {
                ViewBag.Message = "❌ Internal error: " + ex.Message;
                System.Diagnostics.Debug.WriteLine("General Error: " + ex.ToString());
                return PartialView("_CreateLoanAccount");
            }
        }

        // -------------------------
        // Part Payment / Pay EMI
        // -------------------------
        // GET: Partial View

        [HttpGet]
        public PartialViewResult _PayEMI()
        {
            return PartialView("_PayEMI");
        }

        // POST: Fetch Loan Details for Part Payment (AJAX)
        [HttpPost]
        public JsonResult FetchLoanForPartEMI(string LNAccountId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(LNAccountId))
                    return Json(new { success = false, message = "Loan Account ID is required." });

                var loan = _context.LoanAccounts.FirstOrDefault(l => l.LNAccountId == LNAccountId && l.LoanStatus == "Active");
                if (loan == null)
                    return Json(new { success = false, message = "Loan not found or inactive." });

                return Json(new
                {
                    success = true,
                    data = new
                    {
                        loan.LNAccountId,
                        loan.Interest,
                        loan.DueAmount
                    }
                });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // POST: Pay Part EMI (AJAX)
        [HttpPost]
        public JsonResult PayPartEMI(string LNAccountId, decimal Amount)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(LNAccountId))
                    return Json(new { success = false, message = "Loan Account ID is required." });

                var result = _managerService.PayPartEMI(LNAccountId, Amount);

                return Json(new
                {
                    success = result.Success,
                    message = result.Message,
                    DueAmount = result.RemainingDue,
                    PaidAmount = result.PaidAmount,
                    LNAccountId
                });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error paying EMI: " + ex.Message });
            }
        }



        // -------------------------
        // Partial View Loader
        // -------------------------
        [HttpGet]
        public ActionResult _ForecloseLoan()
        {
            try
            {
                return PartialView("_ForecloseLoan");
            }
            catch (Exception ex)
            {
                // Log exception here
                return new HttpStatusCodeResult(500, "Error loading Foreclose Loan partial: " + ex.Message);
            }
        }


        // -------------------------
        // Autocomplete: Active Loan Accounts
        // -------------------------
        [HttpGet]
        public JsonResult GetActiveLoanAccounts(string term)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(term))
                    return Json(new object[0], JsonRequestBehavior.AllowGet);

                var accounts = _context.LoanAccounts
                    .Where(l => l.LNAccountId.StartsWith(term) && l.LoanStatus == "Active")
                    .Select(l => new { label = l.LNAccountId, value = l.LNAccountId })
                    .ToList();

                return Json(accounts, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                // Log exception
                return Json(new { success = false, message = "Server error: " + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        // -------------------------
        // Fetch Loan Details
        // -------------------------
        [HttpPost]
        public JsonResult FetchLoanDetails(string loanAccountId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(loanAccountId))
                    return Json(new { success = false, message = "Loan Account ID is required." });

                var result = _managerService.GetLoanDetails(loanAccountId);

                if (result == null)
                    return Json(new { success = false, message = "Loan not found." });

                return Json(new { success = true, message = "Loan details fetched successfully.", data = result });
            }
            catch (Exception ex)
            {
                // Log exception
                return Json(new { success = false, message = "Server error: " + ex.Message });
            }
        }


        // -------------------------
        // Foreclose / Pay Loan
        // -------------------------
        [HttpPost]
        public JsonResult Foreclose(string loanAccountId, decimal amount)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(loanAccountId))
                    return Json(new { success = false, message = "Loan Account ID is required." });

                if (amount <= 0)
                    return Json(new { success = false, message = "Invalid payment amount." });

                // Call the service (returns a tuple, never null)
                var result = _managerService.ForecloseLoan(loanAccountId, amount);

                // Directly return the result
                return Json(new { success = result.Success, message = result.Message });
            }
            catch (Exception ex)
            {
                // Log exception if needed
                return Json(new { success = false, message = "Error during foreclosure: " + ex.Message });
            }
        }

        // -------------------------
        // Loan Transactions Partial View
        // -------------------------


        // Partial view to enter LoanAccountId
        [HttpGet]
        public PartialViewResult _ViewLoanTransactions(string LNAccountId)
        {
            if (string.IsNullOrWhiteSpace(LNAccountId))
            {
                return PartialView("_ViewLoanTransactions");
            }

            try
            {
                var transactions = _managerService.GetLoanTransactionsByAccountId(LNAccountId) ?? new List<LoanTransaction>();
                var loanAccount = _context.LoanAccounts.FirstOrDefault(l => l.LNAccountId == LNAccountId);
                ViewBag.InitialLoanAmount = loanAccount?.LoanAmount ?? 0m;

                return PartialView("_LoanTransactionList", transactions);
            }
            catch (Exception ex)
            {
                ViewBag.Error = "An error occurred while loading transactions: " + ex.Message;
                return PartialView("_LoanTransactionList", new List<LoanTransaction>());
            }
        }

        // Autocomplete source
        [HttpGet]
        public JsonResult GetLoanAccountIds(string searchTerm)
        {
            var ids = _managerService.GetLoanAccountIds(searchTerm);
            return Json(ids, JsonRequestBehavior.AllowGet);
        }

        // Export PDF
        [HttpGet]
        public ActionResult ExportLoanTransactionsPdf(string LNAccountId)
        {
            var transactions = _managerService.GetLoanTransactionsByAccountId(LNAccountId);
            var loanAccount = _context.LoanAccounts.FirstOrDefault(l => l.LNAccountId == LNAccountId);
            decimal runningBalance = loanAccount?.LoanAmount ?? 0m;

            using (MemoryStream ms = new MemoryStream())
            {
                var doc = new iTextSharp.text.Document();
                iTextSharp.text.pdf.PdfWriter.GetInstance(doc, ms);
                doc.Open();

                doc.Add(new iTextSharp.text.Paragraph($"Loan Account Transactions: {LNAccountId}"));
                doc.Add(new iTextSharp.text.Paragraph(" "));

                var table = new iTextSharp.text.pdf.PdfPTable(5); // 5 columns now (no penalty)
                table.WidthPercentage = 100;
                table.AddCell("Transaction ID");
                table.AddCell("Type");
                table.AddCell("Amount");
                table.AddCell(" Date");
                table.AddCell("Remaining Balance");

                foreach (var t in transactions.OrderBy(x => x.TransactionDate))
                {
                    decimal amount = t.Amount ?? 0;

                    if (t.TransactionType?.ToLower() == "payment" || t.TransactionType?.ToLower() == "emi" || t.TransactionType?.ToLower() == "part emi")
                        runningBalance -= amount;
                    else if (t.TransactionType?.ToLower() == "disbursement")
                        runningBalance += amount;

                    table.AddCell(t.TransactionId.ToString());
                    table.AddCell(t.TransactionType);
                    table.AddCell(amount.ToString("C"));
                    table.AddCell(t.TransactionDate?.ToString("dd-MM-yyyy") ?? "-");
                    table.AddCell(runningBalance.ToString("C"));
                }

                doc.Add(table);
                doc.Close();

                byte[] bytes = ms.ToArray();
                return File(bytes, "application/pdf", $"LoanTransactions_{LNAccountId}.pdf");
            }
        }


        // Export Excel
        [HttpGet]
        public ActionResult ExportLoanTransactions(string LNAccountId)
        {
            var transactions = _managerService.GetLoanTransactionsByAccountId(LNAccountId) ?? new List<LoanTransaction>();
            var loanAccount = _managerService.GetLoanAccountById(LNAccountId);
            decimal runningBalance = loanAccount?.LoanAmount ?? 0m;

            using (var package = new ExcelPackage())
            {
                var ws = package.Workbook.Worksheets.Add("Loan Transactions");

                ws.Cells[1, 1].Value = "Transaction ID";
                ws.Cells[1, 2].Value = "Type";
                ws.Cells[1, 3].Value = "Amount";
                ws.Cells[1, 4].Value = "Date";
                ws.Cells[1, 5].Value = "Remaining Balance";

                int row = 2;
                foreach (var t in transactions.OrderBy(x => x.TransactionDate))
                {
                    decimal amount = t.Amount ?? 0;

                    if (t.TransactionType?.ToLower() == "payment" || t.TransactionType?.ToLower() == "emi" || t.TransactionType?.ToLower() == "part emi")
                        runningBalance -= amount;
                    else if (t.TransactionType?.ToLower() == "disbursement")
                        runningBalance += amount;

                    ws.Cells[row, 1].Value = t.TransactionId;
                    ws.Cells[row, 2].Value = t.TransactionType;
                    ws.Cells[row, 3].Value = amount;
                    ws.Cells[row, 4].Value = t.TransactionDate?.ToString("dd-MM-yyyy") ?? "-";
                    ws.Cells[row, 5].Value = runningBalance;

                    ws.Cells[row, 3].Style.Numberformat.Format = "₹ #,##0.00";
                    ws.Cells[row, 5].Style.Numberformat.Format = "₹ #,##0.00";

                    row++;
                }

                ws.Cells.AutoFitColumns();

                var stream = new MemoryStream();
                package.SaveAs(stream);
                stream.Position = 0;

                string fileName = $"LoanTransactions_{LNAccountId}_{DateTime.Now:yyyyMMddHHmmss}.xlsx";
                return File(stream,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            fileName);
            }
        }




        // -------------------------
        // Partial View Loader
        // -------------------------
        [HttpGet]
        public PartialViewResult _MakeEMIPayment()
        {
            return PartialView("_MakeEMIPayment");
        }

        // -------------------------
        // Fetch Loan Details for EMI Payment
        // -------------------------
        [HttpPost]
        public JsonResult FetchLoanForEMI(string LNAccountId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(LNAccountId))
                    return Json(new { success = false, message = "Loan Account ID is required." });

                var loan = _context.LoanAccounts.FirstOrDefault(l => l.LNAccountId == LNAccountId && l.LoanStatus == "Active");
                if (loan == null)
                    return Json(new { success = false, message = "Loan not found or inactive." });

                // Calculate EMI if not set
                if (loan.Emi == 0)
                {
                    var monthlyInterestRate = loan.Interest / 100 / 12;
                    var months = (int)(loan.TimePeriod * 12);

                    var emi = loan.LoanAmount * monthlyInterestRate *
                              (decimal)Math.Pow(1 + (double)monthlyInterestRate, months) /
                              (decimal)(Math.Pow(1 + (double)monthlyInterestRate, months) - 1);

                    loan.Emi = Math.Round((decimal)emi, 2);
                    loan.TotalPayable = Math.Round(loan.Emi.Value * months, 2);
                    loan.DueAmount = loan.TotalPayable;
                    _context.SaveChanges();
                }

                return Json(new
                {
                    success = true,
                    data = new
                    {
                        loan.LNAccountId,
                        TotalPayable = Math.Round((decimal)loan.TotalPayable, 2),
                        Interest = Math.Round((decimal)loan.Interest, 2),
                        EMI = Math.Round(loan.Emi ?? 0, 2),
                        DueAmount = Math.Round((decimal)loan.DueAmount, 2)
                    }
                });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }


        // -------------------------
        // Pay EMI
        // -------------------------
        [HttpPost]
        public JsonResult PayEMI(string LNAccountId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(LNAccountId))
                    return Json(new { success = false, message = "Loan Account ID is required." });

                var loan = _managerService.MakeEMIPayment(LNAccountId);

                return Json(new
                {
                    success = true,
                    message = $"EMI of ₹{loan.Emi:F2} paid successfully for Loan Account ID: {loan.LNAccountId}.",
                    remainingDue = loan.DueAmount
                });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }





        // GET: Manager/Customers
        public ActionResult Customers()
        {
            // Placeholder for Customer logic
            return View();
        }
    
//----------------------------------------------------------------------------

//FD

// Entry point 

public ActionResult Index(string id)
        {
            if (string.IsNullOrEmpty(id) || !_managerService.IsEmployeeOrManager(id))
            {
                TempData["Error"] = "Access denied.";
                return View("_AccessDeniedPartial");
            }
            ViewBag.RefId = id;

            return View();
        }
        public ActionResult FD(string id)
        {
            if (string.IsNullOrEmpty(id) || !_managerService.IsEmployeeOrManager(id))
            {
                TempData["Error"] = "Access denied.";
                return View("_AccessDeniedPartial");
            }

            ViewBag.RefId = id;
            return View(); 
        }
        

        public PartialViewResult CreateFD(string id)
        {
            if (string.IsNullOrEmpty(id) || !_managerService.IsEmployeeOrManager(id))
                return PartialView("_AccessDeniedPartial");

            ViewBag.CustomerList = new SelectList(_managerService.GetEligibleCustomers(), "CustomerId", "CustomerId");
            ViewBag.RefId = id;
            return PartialView("_CreateFD", new FixedDeposit());
        }

        [HttpPost]
        public PartialViewResult CreateFD(FixedDeposit fd, string id)
        {
            if (string.IsNullOrEmpty(id) || !_managerService.IsEmployeeOrManager(id))
            {
                ViewBag.Error = "Access denied.";
                return PartialView("_AccessDeniedPartial");
            }

            try
            {
                var createdFD = _managerService.CreateFD(fd, id);
                ViewBag.CustomerList = new SelectList(_managerService.GetEligibleCustomers(), "CustomerId", "CustomerId");
                ViewBag.RefId = id;
                ViewBag.SuccessMessage = $"FD created successfully. FD ID: {createdFD.FDAccountId}, Maturity Amount: ₹{createdFD.MaturityAmount}";
                ModelState.Clear();
                return PartialView("_CreateFD", new FixedDeposit());
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                ViewBag.CustomerList = new SelectList(_managerService.GetEligibleCustomers(), "CustomerId", "CustomerId");
                ViewBag.RefId = id;
                return PartialView("_CreateFD", fd);
            }
        }

        public PartialViewResult CloseFD(string id)
        {
            ViewBag.RefId = id;
            ViewBag.FDList = new SelectList(_managerService.GetMaturedFDs(), "FDAccountId", "FDAccountId");
            return PartialView("_CloseFD");
        }

        [HttpPost]
        public PartialViewResult CloseFD(string fdAccountId, string id)
        {
            try
            {
                var message = _managerService.CloseFD(fdAccountId, id);
                ViewBag.SuccessMessage = message;
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }

            ViewBag.RefId = id;
            ViewBag.FDList = new SelectList(_managerService.GetActiveFDs(), "FDAccountId", "FDAccountId");
            return PartialView("_CloseFD");
        }

        

        public PartialViewResult PrematureWithdrawal(string id)
        {
            ViewBag.RefId = id;
            ViewBag.FDList = new SelectList(_managerService.GetNonMaturedFDs(), "FDAccountId", "FDAccountId");
            return PartialView("_PrematureWithdrawal");
        }

        [HttpPost]
        public PartialViewResult PrematureWithdrawal(string fdAccountId, string id)
        {
            try
            {
                var message = _managerService.PrematureWithdrawFD(fdAccountId, id);
                ViewBag.SuccessMessage = message;
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }

            ViewBag.RefId = id;
            ViewBag.FDList = new SelectList(_managerService.GetActiveFDs(), "FDAccountId", "FDAccountId");
            return PartialView("_PrematureWithdrawal");
        }

        public PartialViewResult FDTransactions(string id)
        {
            var transactions = _managerService.GetFDTransactions(id);
            ViewBag.RefId = id;
            return PartialView("_FDTransactions", transactions);
        }


        public PartialViewResult AccessDenied()
        {
            return PartialView("_AccessDeniedPartial");
        }

        public ActionResult FDSummary(string id)
        {
            var fdList = _managerService.GetFDsCreatedBy(id);
            ViewBag.RefId = id;
            return View(fdList);
        }
    }
}