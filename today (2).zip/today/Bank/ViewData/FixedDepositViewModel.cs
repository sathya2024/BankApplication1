﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.ViewData
{
    public class FixedDepositViewModel
    {
        public string FDAccountId { get; set; }
        public string CustomerId { get; set; }
        public decimal Amount { get; set; }
        public decimal ROI { get; set; }
        public int TenureMonths { get; set; }
        public decimal MaturityAmount { get; set; }
        public string MaturityDate { get; set; }
        public string Status { get; set; }
        public string OpenDate { get; set; }
        public string CloseDate { get; set; }

    }
}
